﻿
namespace EPS.Page
{
    partial class AnalyticsPage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AnalyticsPage));
            DevExpress.XtraCharts.XYDiagram xyDiagram2 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series2 = new DevExpress.XtraCharts.Series();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lb_supplier2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lb_supplier1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lb_customer1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lb_customer2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.lb_buy1 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lb_buy2 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.lb_sell1 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lb_sell2 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lb_benfit2 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.lb_benfit1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.chartControl1 = new DevExpress.XtraCharts.ChartControl();
            this.btn_add = new DevExpress.XtraEditors.SimpleButton();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel1.Controls.Add(this.panel2);
            this.flowLayoutPanel1.Controls.Add(this.panel4);
            this.flowLayoutPanel1.Controls.Add(this.panel6);
            this.flowLayoutPanel1.Controls.Add(this.panel8);
            this.flowLayoutPanel1.Controls.Add(this.panel10);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1330, 459);
            this.flowLayoutPanel1.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.lb_supplier1);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.lb_supplier2);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(20, 20);
            this.panel2.Margin = new System.Windows.Forms.Padding(20);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(488, 305);
            this.panel2.TabIndex = 1;
            // 
            // lb_supplier2
            // 
            this.lb_supplier2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_supplier2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_supplier2.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_supplier2.ForeColor = System.Drawing.Color.White;
            this.lb_supplier2.Location = new System.Drawing.Point(0, 246);
            this.lb_supplier2.Name = "lb_supplier2";
            this.lb_supplier2.Size = new System.Drawing.Size(488, 59);
            this.lb_supplier2.TabIndex = 2;
            this.lb_supplier2.Text = "0.00";
            this.lb_supplier2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(13, 49);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(135, 97);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(488, 31);
            this.panel1.TabIndex = 3;
            // 
            // lb_supplier1
            // 
            this.lb_supplier1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_supplier1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_supplier1.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_supplier1.ForeColor = System.Drawing.Color.White;
            this.lb_supplier1.Location = new System.Drawing.Point(0, 187);
            this.lb_supplier1.Name = "lb_supplier1";
            this.lb_supplier1.Size = new System.Drawing.Size(488, 59);
            this.lb_supplier1.TabIndex = 4;
            this.lb_supplier1.Text = "0.00";
            this.lb_supplier1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(180, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(290, 97);
            this.label2.TabIndex = 5;
            this.label2.Text = "ديون الموردين";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.btn_add);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 716);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1330, 58);
            this.panel3.TabIndex = 6;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.lb_customer1);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.lb_customer2);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Location = new System.Drawing.Point(548, 20);
            this.panel4.Margin = new System.Windows.Forms.Padding(20);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(488, 305);
            this.panel4.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(180, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(290, 97);
            this.label4.TabIndex = 5;
            this.label4.Text = "ديون العملاء";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_customer1
            // 
            this.lb_customer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_customer1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_customer1.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_customer1.ForeColor = System.Drawing.Color.White;
            this.lb_customer1.Location = new System.Drawing.Point(0, 187);
            this.lb_customer1.Name = "lb_customer1";
            this.lb_customer1.Size = new System.Drawing.Size(488, 59);
            this.lb_customer1.TabIndex = 4;
            this.lb_customer1.Text = "0.00";
            this.lb_customer1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(488, 31);
            this.panel5.TabIndex = 3;
            // 
            // lb_customer2
            // 
            this.lb_customer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_customer2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_customer2.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_customer2.ForeColor = System.Drawing.Color.White;
            this.lb_customer2.Location = new System.Drawing.Point(0, 246);
            this.lb_customer2.Name = "lb_customer2";
            this.lb_customer2.Size = new System.Drawing.Size(488, 59);
            this.lb_customer2.TabIndex = 2;
            this.lb_customer2.Text = "0.00";
            this.lb_customer2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 49);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(135, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.lb_buy1);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Controls.Add(this.lb_buy2);
            this.panel6.Controls.Add(this.pictureBox3);
            this.panel6.Location = new System.Drawing.Point(20, 365);
            this.panel6.Margin = new System.Windows.Forms.Padding(20);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(488, 305);
            this.panel6.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(180, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(290, 97);
            this.label7.TabIndex = 5;
            this.label7.Text = "عمليات الشراء";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_buy1
            // 
            this.lb_buy1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_buy1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_buy1.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_buy1.ForeColor = System.Drawing.Color.White;
            this.lb_buy1.Location = new System.Drawing.Point(0, 187);
            this.lb_buy1.Name = "lb_buy1";
            this.lb_buy1.Size = new System.Drawing.Size(488, 59);
            this.lb_buy1.TabIndex = 4;
            this.lb_buy1.Text = "0.00";
            this.lb_buy1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Teal;
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(488, 31);
            this.panel7.TabIndex = 3;
            // 
            // lb_buy2
            // 
            this.lb_buy2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_buy2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_buy2.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_buy2.ForeColor = System.Drawing.Color.White;
            this.lb_buy2.Location = new System.Drawing.Point(0, 246);
            this.lb_buy2.Name = "lb_buy2";
            this.lb_buy2.Size = new System.Drawing.Size(488, 59);
            this.lb_buy2.TabIndex = 2;
            this.lb_buy2.Text = "0.00";
            this.lb_buy2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(13, 49);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(135, 97);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel8.Controls.Add(this.label10);
            this.panel8.Controls.Add(this.lb_sell1);
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Controls.Add(this.lb_sell2);
            this.panel8.Controls.Add(this.pictureBox4);
            this.panel8.Location = new System.Drawing.Point(548, 365);
            this.panel8.Margin = new System.Windows.Forms.Padding(20);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(488, 305);
            this.panel8.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(180, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(290, 97);
            this.label10.TabIndex = 5;
            this.label10.Text = "عمليات البيع";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_sell1
            // 
            this.lb_sell1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_sell1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_sell1.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_sell1.ForeColor = System.Drawing.Color.White;
            this.lb_sell1.Location = new System.Drawing.Point(0, 187);
            this.lb_sell1.Name = "lb_sell1";
            this.lb_sell1.Size = new System.Drawing.Size(488, 59);
            this.lb_sell1.TabIndex = 4;
            this.lb_sell1.Text = "0.00";
            this.lb_sell1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(488, 31);
            this.panel9.TabIndex = 3;
            // 
            // lb_sell2
            // 
            this.lb_sell2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_sell2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_sell2.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_sell2.ForeColor = System.Drawing.Color.White;
            this.lb_sell2.Location = new System.Drawing.Point(0, 246);
            this.lb_sell2.Name = "lb_sell2";
            this.lb_sell2.Size = new System.Drawing.Size(488, 59);
            this.lb_sell2.TabIndex = 2;
            this.lb_sell2.Text = "0.00";
            this.lb_sell2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(13, 49);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(135, 97);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(13, 49);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(135, 97);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // lb_benfit2
            // 
            this.lb_benfit2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_benfit2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_benfit2.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_benfit2.ForeColor = System.Drawing.Color.White;
            this.lb_benfit2.Location = new System.Drawing.Point(0, 246);
            this.lb_benfit2.Name = "lb_benfit2";
            this.lb_benfit2.Size = new System.Drawing.Size(488, 59);
            this.lb_benfit2.TabIndex = 2;
            this.lb_benfit2.Text = "0.00";
            this.lb_benfit2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Olive;
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(488, 31);
            this.panel11.TabIndex = 3;
            // 
            // lb_benfit1
            // 
            this.lb_benfit1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_benfit1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_benfit1.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_benfit1.ForeColor = System.Drawing.Color.White;
            this.lb_benfit1.Location = new System.Drawing.Point(0, 187);
            this.lb_benfit1.Name = "lb_benfit1";
            this.lb_benfit1.Size = new System.Drawing.Size(488, 59);
            this.lb_benfit1.TabIndex = 4;
            this.lb_benfit1.Text = "0.00";
            this.lb_benfit1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("LBC", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(180, 58);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(290, 97);
            this.label13.TabIndex = 5;
            this.label13.Text = "الارباح المتوقعة";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel10.Controls.Add(this.label13);
            this.panel10.Controls.Add(this.lb_benfit1);
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.lb_benfit2);
            this.panel10.Controls.Add(this.pictureBox5);
            this.panel10.Location = new System.Drawing.Point(20, 710);
            this.panel10.Margin = new System.Windows.Forms.Padding(20);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(488, 305);
            this.panel10.TabIndex = 5;
            // 
            // chartControl1
            // 
            this.chartControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartControl1.AppearanceNameSerializable = "Dark Flat";
            this.chartControl1.DataSource = typeof(EPS.TB_Sell);
            xyDiagram2.AxisX.Title.Text = "الايام";
            xyDiagram2.AxisX.Title.Visibility = DevExpress.Utils.DefaultBoolean.True;
            xyDiagram2.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram2.AxisY.Title.Text = "المبيعات";
            xyDiagram2.AxisY.Title.Visibility = DevExpress.Utils.DefaultBoolean.True;
            xyDiagram2.AxisY.VisibleInPanesSerializable = "-1";
            this.chartControl1.Diagram = xyDiagram2;
            this.chartControl1.Legend.Border.Visibility = DevExpress.Utils.DefaultBoolean.True;
            this.chartControl1.Legend.Visibility = DevExpress.Utils.DefaultBoolean.True;
            this.chartControl1.Location = new System.Drawing.Point(-1, 484);
            this.chartControl1.Name = "chartControl1";
            this.chartControl1.PaletteBaseColorNumber = 1;
            series2.ArgumentDataMember = "Date";
            series2.Name = "المبيعات";
            series2.ValueDataMembersSerializable = "SellValue";
            this.chartControl1.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series2};
            this.chartControl1.Size = new System.Drawing.Size(1330, 225);
            this.chartControl1.TabIndex = 5;
            // 
            // btn_add
            // 
            this.btn_add.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btn_add.Appearance.Font = new System.Drawing.Font("LBC", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.Appearance.Options.UseFont = true;
            this.btn_add.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.btn_add.Location = new System.Drawing.Point(924, 8);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(403, 47);
            this.btn_add.TabIndex = 1;
            this.btn_add.Text = "تحديث البيانات";
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.Font = new System.Drawing.Font("LBC", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(3, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(864, 45);
            this.label1.TabIndex = 6;
            this.label1.Text = "تحتاج الى تحديث كافة البيانات في الصفحات البرنامج لجلب البيانات بشكل الصحيح";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AnalyticsPage
            // 
            this.Appearance.BackColor = System.Drawing.Color.White;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.chartControl1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "AnalyticsPage";
            this.Size = new System.Drawing.Size(1330, 774);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(xyDiagram2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lb_supplier2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private DevExpress.XtraCharts.ChartControl chartControl1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_supplier1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lb_customer1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lb_customer2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lb_buy1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lb_buy2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lb_sell1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lb_sell2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lb_benfit1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label lb_benfit2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private DevExpress.XtraEditors.SimpleButton btn_add;
        private System.Windows.Forms.Label label1;
    }
}
