﻿using DevExpress.XtraReports.UI;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

namespace EPS.Report
{
    public partial class SystemLogs : DevExpress.XtraReports.UI.XtraReport
    {
        public SystemLogs()
        {
            InitializeComponent();
        }

    }
}
