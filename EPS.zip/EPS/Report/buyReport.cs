﻿using DevExpress.XtraReports.UI;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

namespace EPS.Report
{
    public partial class buyReport : DevExpress.XtraReports.UI.XtraReport
    {
        public buyReport()
        {
            InitializeComponent();
        }

    }
}
